@extends('index')
@section('contenido')
<div class="container">
        <div class="row mt-5">        
            <div class="col-md-6">
            <h3>Contacto</h3>
                <!-- Formulario de contacto -->
                <form action="procesar_formulario.php" method="POST">
                    <div class="form-group mt-2">
                        <label for="nombre">Nombre:</label>
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                    <div class="form-group mt-2">
                        <label for="email">Correo Electrónico:</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="form-group mt-2">
                        <label for="mensaje">Mensaje:</label>
                        <textarea class="form-control" id="mensaje" name="mensaje" rows="4" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-info mt-2">Enviar</button>
                </form>
            </div>

            <div class="col-md-6">
                <!-- Datos de la empresa -->
                <h3>Datos de la Empresa</h3>
                <p>Nombre de la Empresa: JossyTea</p>
                <p>Dirección: Calle León de Febres Cordero, Samborondón, Ecuador</p>
                <p>Teléfono: +123456789</p>
                <p>Correo Electrónico: info@uees.edu.ec</p>

                <!-- Mapa de Google -->
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3987.053135389416!2d-79.87086280321043!3d-2.1332818999999974!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x902d6ce70389539b%3A0x47f54e8a54356fd1!2sUniversidad%20Esp%C3%ADritu%20Santo!5e0!3m2!1ses!2sec!4v1696197416864!5m2!1ses!2sec" width="100%" height="400" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            
            </div>
        </div>
    </div>

    @endsection    