<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductoController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/inicio', [ProductoController::class, 'mostrarProductos'])->name('inicio');

Route::get('/login', function () {
    return view('login');
});

Route::get('/guardarProducto', function () {
    return view('producto');
});

Route::get('/contacto', function () {
    return view('contacto');
});


Route::post('/guardarProducto',[ProductoController::class,'guardarProducto'])->name('guardarProducto');

Route::get('/categoria/{categoria_id}', [ProductoController::class, 'mostrarCategoria']);

Route::get('/buscarProducto', [ProductoController::class, 'buscarProducto'])->name('buscarProducto');
