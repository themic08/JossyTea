<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Producto;

class ProductoController extends Controller
{
    public function guardarProducto(Request $request)
    {
        $producto = new Producto;
                
        $producto->nombre=$request->nombre;
        $producto->descripcion=$request->descripcion;
        $producto->precio=$request->precio;
        $producto->categoria=$request->categoria;
        $producto->puntuacion=$request->puntuacion;

        if ($request->hasFile('imagen')) {
            $imagen = $request->file('imagen');
            $nombreImagen = time() . '_' . $imagen->getClientOriginalName();
            $rutaImagen = $imagen->storeAs('public/imagenes', $nombreImagen);

            $producto->nombreImg = $nombreImagen;
            $producto->rutaImg= $rutaImagen;
        }
       
        $producto->save();
        return redirect()->route('guardarProducto')->with('success', 'Producto guardado exitosamente.');
    }

    public function mostrarProductos()
    {
        $productos = Producto::all();
        return view('inicio', ['productos' => $productos]);
    }

    public function mostrarCategoria($idCategoria)
    {
        $productos = Producto::where('categoria', $idCategoria)->get();
        return view('categoria', ['productos' => $productos, 'titulo' => $idCategoria]);
    }

    public function buscarProducto(Request $request)
    {
        $nombre = $request->input('nombre');

        // Realiza la búsqueda de productos por nombre
        $productos = Producto::where('nombre', 'like', "%$nombre%")->get();

        return view('categoria', ['productos' => $productos, 'titulo' => 'Buscastes:"'.$nombre.'"']);
    }
}
