
<?php $__env->startSection('contenido'); ?>
<title>Login</title>
  <div class="d-flex justify-content-center align-items-center vh-150 m-4">
    <div
      class="contiene_login p-4 rounded-5 text-secondary shadow"
      style="width: 25rem"
    >
      <div class="d-flex justify-content-center">
      <i class="bi bi-person-circle display-4"></i>
      </div>
      <div class="input-group mt-4">
        <div class="input-group-text bg-info ">
        <span class="input-group-text"><i class="fas fa-user"></i></span>
        </div>
        <input
          class="form-control bg-light"
          type="text"
          placeholder="Usuario"
        />
      </div>
      <div class="input-group mt-1">
        <div class="input-group-text bg-info ">
        <span class="input-group-text"><i class="fas fa-lock"></i></span>
        </div>
        <input
          class="form-control bg-light"
          type="password"
          placeholder="Contraseña"
        />
      </div>
      <div class="d-flex justify-content-around mt-1">
        <div class="d-flex align-items-center gap-1">
          <input class="form-check-input" type="checkbox" />
          <div class="pt-1" style="font-size: 0.9rem">Recordarme</div>
        </div>
        <div class="pt-1">
          <a
            href="#"
            class="text-decoration-none text-info fw-semibold fst-italic "
            style="font-size: 0.9rem"
            >Olvidaste tu contraseña?</a
          >
        </div>
      </div>
      <div class="btn btn-info text-white w-100 mt-4 fw-semibold shadow-sm ">
        Login
      </div>
      <div class="d-flex gap-1 justify-content-center mt-1">
        <div>No tengo una cuenta?</div>
        <a href="#" class="text-decoration-none text-info fw-semibold "
          >Registrarse</a
        >
      </div>      
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jossyTea\resources\views/login.blade.php ENDPATH**/ ?>