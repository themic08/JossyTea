
<?php $__env->startSection('contenido'); ?>
<title>Inicio</title>

<div class="container mt-3">
        <h1 class="text-center titulos_principales">Nuestros productos</h1>
        
        <div class="row">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mt-2 mb-4">
                    <div class="card px-2">
                        <img src="<?php echo e(asset('storage/imagenes/' . $producto->nombreImg)); ?>" class="imagen-fija card-img-top px-3" alt="<?php echo e($producto->nombre); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($producto->nombre); ?></h5>
                            <p class="card-text"><?php echo e($producto->categoria); ?></p>
                            <p class="card-text texto_descipcion"><?php echo e($producto->descripcion); ?></p>
                            <p class="card-text"><?php echo e($producto->puntuacion); ?></p>
                            <p class="card-text">Precio: $<?php echo e($producto->precio); ?></p>
                            <div class="justify-content-center align-items-center">
                                <!-- Centrar horizontal y verticalmente -->
                                <div class="text-center">
                                    <a href="#" class="btn btn-info">Ver</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <h1 class="text-center titulos_principales">Conócenos</h1>
<div class="container py-3 px-4">
        <div class="row">
            <!-- Columna 1 -->
            <div class="col-md-3">
                <div class="item">
                    <i class="fas fa-truck"></i>
                    <h4>Envíos a todo Ecuador</h4>
                    <p>El valor del envío se calcula al final de la compra.</p>
                </div>
            </div>

            <!-- Columna 2 -->
            <div class="col-md-3">
                <div class="item">
                    <i class="fas fa-mug-hot"></i>
                    <h4>Té premiun</h4>
                    <p>Los mejores tés y mezclas de autor.</p>
                </div>
            </div>

            <!-- Columna 3 -->
            <div class="col-md-3">
                <div class="item">
                    <i class="fas fa-percent"></i>
                    <h4>Promociones especiales</h4>
                    <p>Tenemos promociones vigentes que se adaptan a ti.</p>
                </div>
            </div>

            <!-- Columna 4 -->
            <div class="col-md-3">
                <div class="item">
                    <i class="fas fa-lock"></i>
                    <h4>Compra segura</h4>
                    <p>Recuerda que todas tus compras están seguras.</p>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jossyTea\resources\views/inicio.blade.php ENDPATH**/ ?>