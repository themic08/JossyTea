
<?php $__env->startSection('contenido'); ?>
<title>Categoria</title>

<div class="container mt-3">
        <h1 class="text-center titulos_principales">
           <?php echo e($titulo); ?>

        </h1>
        
        <div class="row">
            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 mt-2 mb-4">
                    <div class="card px-2">
                        <img src="<?php echo e(asset('storage/imagenes/' . $producto->nombreImg)); ?>" class="imagen-fija card-img-top px-3" alt="<?php echo e($producto->nombre); ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($producto->nombre); ?></h5>
                            <p class="card-text"><?php echo e($producto->categoria); ?></p>
                            <p class="card-text texto_descipcion"><?php echo e($producto->descripcion); ?></p>
                            <p class="card-text"><?php echo e($producto->puntuacion); ?></p>
                            <p class="card-text">Precio: $<?php echo e($producto->precio); ?></p>
                            <div class="justify-content-center align-items-center">
                                <!-- Centrar horizontal y verticalmente -->
                                <div class="text-center">
                                    <a href="#" class="btn btn-info">Ver</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jossyTea\resources\views/categoria.blade.php ENDPATH**/ ?>