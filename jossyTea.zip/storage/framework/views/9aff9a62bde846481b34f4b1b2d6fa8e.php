<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet" >
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
     <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css" rel="stylesheet" >
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.17.0/font/bootstrap-icons.css">
    <style>

    .color-purpura {
        background-color: #BA6CEE;
        color: white;
    }

    .logo-container {
        text-align: center;
        margin-top: 20px;
    }

    .logo-text {
        font-family: "Arial", sans-serif;
        font-size: 36px;
        font-weight: bold;
        color: #4CAF50;
        letter-spacing: 2px;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    }

    .tea-icon {
        font-size: 48px;
        margin-top: 10px;
        color: #FFA500;
    }
    a {
        text-decoration: none;
    }

    .item {
        text-align: center;
    }

    .item i {
        font-size: 2rem;
        color: #4B0082;        
    }

    .item h4 {
        font-size: 1.5rem;
        margin-top: 10px;
        color: #4B0082;
    }

    .item p {
        font-size: 1rem;
    }

    .contiene_login{
        background-color: #BA6CEE;
    }

    .custom-button {
        background-color: #4B0082;
        color: white;
        border: none;
        padding: 10px 20px;
        transition: background-color 0.3s; 
    }

    .custom-button:hover {
        background-color: #A130EA;
    }

    .list-unstyled li a {
        text-decoration: none;
        color: #fff;
    }

    .columna-titulo{
        color: #4B0082;
    }
    .list-inline-item a i {
        color: #4B0082;
    }

    .dropdown-item:hover {
        background-color: #A130EA;
    }

    .contiene_login {
        background-color: #F0DEFB;
    }
    .contenedor_producto{
        max-width: 800px; 
        background-color: #F0DEFB;
    }
    .imagen-fija {
        height: 180px;
    }

    .texto_descipcion{
        font-size: 12px;
    }
    .titulos_principales{        
        color: #4B0082;
    }
    .card-title{     
        color: #4B0082;
    }
    .nav-link:hover {
            color: #fff;
            font-weight: bold;
        }

    </style>
</head>

<body>


<nav class="navbar navbar-expand-lg color-purpura py-2 px-3">
  <div class="container-fluid">
  <a href="#">
        <span class="logo-text">JossyTea</span>
        <span class="tea-icon">&#127861;</span>
        </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse justify-content-end" id="navbarNavDropdown">
    <ul class="navbar-nav justify-content-center">
            <li class="nav-item">
            <a class="nav-link text-light" aria-current="page" href="/inicio">inicio</a>
            </li>
            <li class="nav-item">
            <a class="nav-link text-light" aria-current="page" href="/login">login</a>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Tés
                </a>
                <div class="dropdown-menu color-purpura" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item text-light" href="/categoria/Con Latte">Con Latte</a>
                        <a class="dropdown-item text-light" href="/categoria/Sin Latte">Sin Latte</a>
                    </div>
            </li>
            
            <li class="nav-item">
                <a class="nav-link text-light" aria-current="page" href="/guardarProducto">Ingresar Te</a>
            </li>
            <li class="nav-item">
                <a class="nav-link text-light" aria-current="page" href="/contacto">Contáctenos</a>
            </li>
        </ul>
        <div class="justify-content-end">
            <form class="d-flex" role="search" action="<?php echo e(route('buscarProducto')); ?>" method="GET" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input class="form-control me-2" type="search" placeholder="Buscar" aria-label="Search" name="nombre">
                <button class="custom-button" type="submit">Buscar</button>
            </form>
        </div>
    </div>
  </div>
</nav>
      

<div>

<?php echo $__env->yieldContent('contenido'); ?>
</div>

<footer class="color-purpura p-3 text-center">
        <div class="container px-4">
            <div class="row justify-content-center"> 
                <div class="col-md-4">
                    <h5 class="columna-titulo">Enlaces rápidos</h5>
                    <ul class="list-unstyled">
                        <li><a href="/inicio">Inicio</a></li>
                        <li><a href="/login">login</a></li>
                        <li><a href="/categoria/Con Latte">Tés Con Latte</a></li>
                        <li><a href="/categoria/Sin Latte">Tés Sin Latte</a></li>
                        <li><a href="/guardarProducto">Ingresar Te</a></li>
                        <li><a href="/contacto">Contáctenos</a></li>
                    </ul>
                </div>

                <div class="col-md-4 justify-content-center" >
                    <h5 class="columna-titulo">Distribuidores</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Hoteles</a></li>
                        <li><a href="#">Venta para empresas</a></li>
                        <li><a href="#">Quiero ser distribuidor</a></li>
                    </ul>
                </div>

                <div class="col-md-4 redes-sociales justify-content-center">
                <h5 class="columna-titulo">Información</h5>
                    <ul class="list-unstyled">
                        <li><a href="#">Preguntas frecuentes</a></li>
                        <li><a href="#">Políticas de privacidad</a></li>
                        <li><a href="#">Políticas de distribución</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>

    <div class="redes-sociales text-center pt-3">
        <h5 class="columna-titulo">Redes Sociales</h5>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="#"><i class="bi bi-facebook"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="bi bi-whatsapp"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="bi bi-instagram"></i></a></li>
            <li class="list-inline-item"><a href="#"><i class="bi bi-linkedin"></i></a></li>
        </ul>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap/dist/js/bootstrap.min.js"></script>

</body>

</html><?php /**PATH C:\xampp\htdocs\jossyTea\resources\views/index.blade.php ENDPATH**/ ?>